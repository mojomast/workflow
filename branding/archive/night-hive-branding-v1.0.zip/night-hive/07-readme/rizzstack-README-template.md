<!-- Copy the selected banner to docs/brand/banner.png before using this template. -->
![rizzstack — ecosystem](docs/brand/banner.png)

# rizzstack

rizzstack is an ecosystem with four layers: flww for method, hyvv for worker-host runtime, bzzq for bee orchestration, and orbt for the control surface.

Brand home: rizz.click

## The ecosystem

| Layer | Role |
| --- | --- |
| flww | method |
| hyvv | worker-host runtime |
| bzzq | bee orchestration |
| orbt | control surface |

<!-- Add verified setup, usage, contribution and license information from this project's own documentation. -->
