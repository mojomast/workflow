<!-- Copy the selected banner to docs/brand/banner.png before using this template. -->
![bzzq — orchestration](docs/brand/banner.png)

# bzzq

bzzq is the bee orchestration layer of rizzstack.

Brand home: rizz.click

## The ecosystem

| Layer | Role |
| --- | --- |
| flww | method |
| hyvv | worker-host runtime |
| bzzq | bee orchestration |
| orbt | control surface |

<!-- Add verified setup, usage, contribution and license information from this project's own documentation. -->
