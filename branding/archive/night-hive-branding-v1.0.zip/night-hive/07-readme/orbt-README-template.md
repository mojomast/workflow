<!-- Copy the selected banner to docs/brand/banner.png before using this template. -->
![orbt — control](docs/brand/banner.png)

# orbt

orbt is the control surface layer of rizzstack.

Brand home: rizz.click

## The ecosystem

| Layer | Role |
| --- | --- |
| flww | method |
| hyvv | worker-host runtime |
| bzzq | bee orchestration |
| orbt | control surface |

<!-- Add verified setup, usage, contribution and license information from this project's own documentation. -->
